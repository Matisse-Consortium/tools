# MATISSE python tools

This is a set of python scripts used for the MATISSE commissionning.
They allow one to reduce and visualize data from MATISSE.
Use it at your own risks!